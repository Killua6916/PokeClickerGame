# Welcome to The Pokemon Idle Game!

The point of this game is to find as many pokeballs
as possible. In doing so will give you the ability
to purchase new pokemon, legendarys and more.

